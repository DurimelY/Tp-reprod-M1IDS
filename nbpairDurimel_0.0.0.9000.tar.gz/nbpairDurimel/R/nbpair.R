#' vérifier si n est paire ou impair test
#' @param n entier
#' @return

#' @export


nombre_pair_Durimel<-function (n)
{
  if (n%%2==0)
    return(TRUE)
  else
    return(FALSE)}
